package com.example.undine.project_ooad;

import android.app.Activity;
import android.content.Context;
import android.graphics.Bitmap;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Administrator on 15/11/2558.
 */
public class CommentAdapterFragment extends BaseAdapter {
    private LayoutInflater mInflater;
    List<Comment> mPosts;
    private MyViewHolder commentView;
    private Comment mPost;

    //by nook 2015/11/03
    private static ArrayList<Comment> listContact;
    public CommentAdapterFragment(Context photosFragment, ArrayList<Comment> results){
        listContact = results;
        mInflater = LayoutInflater.from(photosFragment);
        mPosts=results;
    }



    @Override
    public int getCount() {
        return mPosts.size();
    }

    @Override
    public Object getItem(int position) {
        return mPosts.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        if (convertView == null) {
            convertView = mInflater.inflate(R.layout.layout_comment, parent, false);
            commentView = new MyViewHolder();
            commentView.accountImage = (ImageView) convertView.findViewById(R.id.comment_account_image);
            commentView.accountName = (TextView) convertView.findViewById(R.id.account_name);
            commentView.description = (TextView) convertView.findViewById(R.id.descript);


            convertView.setTag(commentView);

        } else {
            commentView = (MyViewHolder) convertView.getTag();

        }

        mPost = mPosts.get(position);
        commentView.accountName.setText(mPost.getAccount().getName());
        commentView.description.setText(mPost.getDescription()+"");

        return convertView;
    }


    private static class MyViewHolder{
        ImageView accountImage;
        TextView accountName;
        TextView description;

    }
}